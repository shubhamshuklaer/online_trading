<?php
    session_start();
     $_SESSION['address']="$&@DEFAULT@&$";
   // session_write_close();
    include_once "checkout.php";
 ?>
